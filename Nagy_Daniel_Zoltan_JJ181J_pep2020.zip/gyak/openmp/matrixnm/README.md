# Feladatkiírás

Készítse el a „Párhuzamos algoritmusok” tárgyból megismert „matrixmn” (MatrixMultiply) program **OpenMP**/Pthreads-s változatát!

Készítsen grafikont a különböző bemenetek esetén összehasonlítva a soros és a 2 szálon történő futtatást!
