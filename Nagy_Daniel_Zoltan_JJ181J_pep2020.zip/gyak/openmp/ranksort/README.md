# Feladatkiírás

Készítse el a „Párhuzamos algoritmusok” tárgyból megismert „ranks” (Ranksort) program **OpenMP**/Pthreads-s változatát!

Készítsen grafikont a különböző bemenetek esetén összehasonlítva a soros és a 2 vagy kettő hatvány szálon történő futtatást!
