# Feladatkiírás

Készítse el a „Párhuzamos algoritmusok” tárgyból megismert „numint” (NumericalIntegration, trapézformula) program OpenMP/**Pthreads**-s változatát!

Készítsen grafikont a különböző bemenetek esetén összehasonlítva a soros és a 2 szálon történő futtatást!

&int;<sub>0</sub><sup>1</sup> = (t + sin t) dt ≈ 0.95969766754.
