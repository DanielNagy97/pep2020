# Feladatkiírás

Készítsünk egy olyan OpenMP/**Pthreads**-s programot, amely meghatározza egy egész elemeket tartalmazó tömb legkisebb elemét. 

Tegyük fel, hogy a tömb elég nagy ahhoz, hogy hatékonyan alkalmazzunk párhuzamos szálakat a programban.

Teszteljük a programot különböző méretű tömbökön is!
