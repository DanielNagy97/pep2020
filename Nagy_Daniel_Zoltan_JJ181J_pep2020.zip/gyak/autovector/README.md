# Feladatkiírás

Készítsen programot, amely rögzített, 1024 × 1024 méretű, egészeket tartalmazó mátrixok szorzását hajtja végre!

Hasonlítsa össze a program futási idejét -O3 optimalizálással, auto-vektorizálással és annak kikapcsolása esetén. A -O3 optimalizálás alapértelmezett módon tartalmazza az auto-vektorizálást!