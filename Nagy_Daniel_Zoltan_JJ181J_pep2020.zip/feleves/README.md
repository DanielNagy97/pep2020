# Feladatkiírás

## Adjunk össze n db mértani sorozatbeli elemet rekurzívan!

# Feltételek:
* OpenMP használata
* R-nyelv segítségével futási idők ábrázolása
* cmake fordítás
* 2 hatványok szerinti (adott esetben logaritmikus) RANDOM inputok
* az előforduló pl. vektorok dimenziója is 2 hatvány
* a szálak száma parancssorból állítható legyen
* minden eset legyen „feldolgozva”
* a távolság számítása általában Euklideszi
* határidők betartása! (11-12. hétre)
