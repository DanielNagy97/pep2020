# pep2020

## Párhuzamos eszközök beadandó feladatok

Nagy Dániel Zoltán

JJ181J

2020.04.14.
